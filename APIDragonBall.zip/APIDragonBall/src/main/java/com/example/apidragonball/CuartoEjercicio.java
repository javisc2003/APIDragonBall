package com.example.apidragonball;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class CuartoEjercicio {
    public static void main(String[] args) {
        System.out.println(obtenerDatosActor(obtenerActor(obtenerPelicula())));
    }
    public static String obtenerPelicula() {
        String Id = "";

        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create("https://moviesminidatabase.p.rapidapi.com/movie/imdb_id/byTitle/Dragonball%20Evolution/"))
                    .header("X-RapidAPI-Key", APIConfig.API_KEY)
                    .header("X-RapidAPI-Host", "moviesminidatabase.p.rapidapi.com")
                    .method("GET", HttpRequest.BodyPublishers.noBody())
                    .build();
            HttpResponse<String> response = HttpClient.newHttpClient().send(request, HttpResponse.BodyHandlers.ofString());
            JSONObject jsonResponse = new JSONObject(response.body());

            JSONArray resultsArray = jsonResponse.getJSONArray("results");
            if (resultsArray.length() > 0) {
                JSONObject movieInfo = resultsArray.getJSONObject(0);
                Id = movieInfo.getString("imdb_id");

                System.out.println("Id de la película: " + Id);
            } else {
                System.out.println("No se encontraron resultados para la película.");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return Id;
    }
    public static String obtenerActor(String id) {
        String actor = "";
        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create("https://moviesminidatabase.p.rapidapi.com/movie/id/"+ id +"/cast/"))
                    .header("X-RapidAPI-Key", APIConfig.API_KEY)
                    .header("X-RapidAPI-Host", "moviesminidatabase.p.rapidapi.com")
                    .method("GET", HttpRequest.BodyPublishers.noBody())
                    .build();
            HttpResponse<String> response = HttpClient.newHttpClient().send(request, HttpResponse.BodyHandlers.ofString());
            JSONObject jsonResponse = new JSONObject(response.body());

            if (jsonResponse.has("results")) {
                JSONArray rolesArray = jsonResponse.getJSONObject("results").getJSONArray("roles");

                for (int i = 0; i < rolesArray.length(); i++) {
                    JSONObject role = rolesArray.getJSONObject(i);

                    if ("Goku".equalsIgnoreCase(role.getString("role"))) {
                        actor = role.getJSONObject("actor").getString("imdb_id");
                        System.out.println("Id del actor: " + actor);
                        break;
                    }
                }
            } else {
                System.out.println("La respuesta no da resultados.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return actor;
    }
    public static JSONObject obtenerDatosActor(String idActor) {
        JSONObject resultObject = new JSONObject();
        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create("https://moviesminidatabase.p.rapidapi.com/actor/id/" + idActor + "/"))
                    .header("X-RapidAPI-Key", APIConfig.API_KEY)
                    .header("X-RapidAPI-Host", "moviesminidatabase.p.rapidapi.com")
                    .method("GET", HttpRequest.BodyPublishers.noBody())
                    .build();
            HttpResponse<String> response = HttpClient.newHttpClient().send(request, HttpResponse.BodyHandlers.ofString());
            JSONObject jsonResponse = new JSONObject(response.body());

            String lugarNacimiento = jsonResponse.getJSONObject("results").getString("birth_place");
            String cumple = jsonResponse.getJSONObject("results").getString("birth_date");
            String signo = jsonResponse.getJSONObject("results").getString("star_sign");

            System.out.println("Lugar de nacimiento: " + lugarNacimiento);
            System.out.println("Fecha de nacimiento: " + cumple);
            System.out.println("Signo del zodíaco: " +  signo);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultObject;
    }
}
