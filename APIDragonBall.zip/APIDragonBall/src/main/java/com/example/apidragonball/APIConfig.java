package com.example.apidragonball;


public class APIConfig {
    public static final String API_KEY = "3c81e5f996msh5cba63f7243bf06p127481jsn8da7c885f494";

}
