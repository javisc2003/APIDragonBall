package com.example.apidragonball;

import org.json.JSONObject;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class SextoEjercicio {
    public static void main(String[] args) {
        try {
            String id = obtenerId();
            System.out.println("ID de Poltergeist: " + id);
            obtenerPremios(id);
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }
    private static String obtenerId() throws IOException, InterruptedException {
        String id = "";

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create("https://moviesminidatabase.p.rapidapi.com/movie/imdb_id/byTitle/poltergeist/"))
                .header("X-RapidAPI-Key", "01d02f25a8msh7a4ca081b7e5405p14f6ddjsnadbf679b6428")
                .header("X-RapidAPI-Host", "moviesminidatabase.p.rapidapi.com")
                .method("GET", HttpRequest.BodyPublishers.noBody())
                .build();

        HttpResponse<String> response = HttpClient.newHttpClient().send(request, HttpResponse.BodyHandlers.ofString());

        JSONObject jsonResponse = new JSONObject(response.body());

        if (jsonResponse.has("results")) {
            id = jsonResponse.getJSONArray("results").getJSONObject(0).getString("imdb_id");
        } else {
            System.out.println("No se encontraron resultados.");
        }
        return id;
    }
    private static String obtenerPremios(String id) throws IOException, InterruptedException {
        String premios = "";

        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create("https://moviesminidatabase.p.rapidapi.com/movie/id/" + id + "/awards/"))
                    .header("X-RapidAPI-Key", APIConfig.API_KEY)
                    .header("X-RapidAPI-Host", "moviesminidatabase.p.rapidapi.com")
                    .method("GET", HttpRequest.BodyPublishers.noBody())
                    .build();
            HttpResponse<String> response = HttpClient.newHttpClient().send(request, HttpResponse.BodyHandlers
                    .ofString());
            JSONObject jsonResponse = new JSONObject(response.body());
            System.out.println(jsonResponse.toString(2));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return premios;
    }
}
